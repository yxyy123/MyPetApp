package com.example.mypetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PetPhotoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_photo);

        ImageView ivPetPhoto = findViewById(R.id.ivPetPhoto);
        TextView tvPhotoDescription = findViewById(R.id.tvPhotoDescription);

        String petName = getIntent().getStringExtra("pet_name");

        if (petName.equals("狗狗")) {
            ivPetPhoto.setImageResource(R.drawable.dog_photo);
            tvPhotoDescription.setText("这是一只可爱的狗狗！");
        } else {
            ivPetPhoto.setImageResource(R.drawable.cat_photo);
            tvPhotoDescription.setText("这是一只可爱的猫咪！");
        }
    }
}