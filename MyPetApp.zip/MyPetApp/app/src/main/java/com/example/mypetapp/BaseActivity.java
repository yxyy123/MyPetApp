package com.example.mypetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BaseActivity extends AppCompatActivity {
    protected BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base); // 所有页面共用布局

        bottomNav = findViewById(R.id.bottom_nav);
        bottomNav.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.nav_personal:
                    startActivity(new Intent(this, PersonalActivity.class));
                    break;
                case R.id.nav_pet_selection:
                    startActivity(new Intent(this, PetSelectionActivity.class));
                    break;
                case R.id.nav_my_pets:
                    startActivity(new Intent(this, MypetsActivity.class));
                    break;
            }
            return true;
        });
    }

    // 设置当前选中的导航项
    protected void setSelectedNavItem(int itemId) {

        bottomNav.setSelectedItemId(itemId);
    }
}