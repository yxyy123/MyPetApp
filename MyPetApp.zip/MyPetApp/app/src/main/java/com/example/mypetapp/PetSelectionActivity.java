package com.example.mypetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

public class PetSelectionActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_selection);
        setSelectedNavItem(R.id.nav_pet_selection);

        // 选择狗狗
        findViewById(R.id.btnSelectDog).setOnClickListener(v -> {
            savePetToPreferences("狗狗");
            Toast.makeText(this, "已选择狗狗！", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MypetsActivity.class));
        });

        // 选择猫咪
        findViewById(R.id.btnSelectCat).setOnClickListener(v -> {
            savePetToPreferences("猫咪");
            Toast.makeText(this, "已选择猫咪！", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MypetsActivity.class));
        });
    }

    // 保存选择的宠物到SharedPreferences
    private void savePetToPreferences(String petName) {
        SharedPreferences preferences = getSharedPreferences("MyPetPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("selected_pet", petName);
        editor.apply();
    }
}
