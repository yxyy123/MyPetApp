package com.example.mypetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText etUsername, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 检查是否已登录
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        if (prefs.getBoolean("is_logged_in", false)) {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);

        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            String username = etUsername.getText().toString();
            String password = etPassword.getText().toString();
            if (checkLogin(username, password)) {
                saveLoginStatus(true);
                startActivity(new Intent(this, MainActivity.class));
                finish();
            } else {
                Toast.makeText(this, "登录失败", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.btnRegister).setOnClickListener(v -> {
            startActivity(new Intent(this, RegisterActivity.class));
        });
    }

    private boolean checkLogin(String username, String password) {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String savedPassword = prefs.getString(username, "");
        return savedPassword.equals(password);
    }

    private void saveLoginStatus(boolean isLoggedIn) {
        SharedPreferences.Editor editor = getSharedPreferences("login_status", MODE_PRIVATE).edit();
        editor.putBoolean("is_logged_in", isLoggedIn);
        editor.apply();
    }

    private void attemptLogin(String username, String password) {
        if (isValidCredentials(username, password)) {
            // 保存登录状态
            SharedPreferences.Editor editor = getSharedPreferences("user_prefs", MODE_PRIVATE).edit();
            editor.putBoolean("is_logged_in", true);
            editor.apply();

            // 跳转主页面并关闭登录页
            startActivity(new Intent(this, MainActivity.class));
            finish(); // 关闭当前Activity
        } else {
            Toast.makeText(this, "登录失败", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidCredentials(String username, String password) {
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        String savedPassword = prefs.getString(username, "");
        return !savedPassword.isEmpty() && savedPassword.equals(password);
    }
}